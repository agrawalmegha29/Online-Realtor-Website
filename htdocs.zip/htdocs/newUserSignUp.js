$(document).ready(function(){
	$("button#submit").click(function()
	{
		var username1 =$("#username1").val();
		var password1 =$("#password1").val();
		var firstName1 =$("#firstName1").val();
		var lastName1 =$("#lastName1").val();
		var emailAddress1 =$("#emailAddress1").val();
		var phoneNumber1 =$("#phoneNumber1").val();
		var optradio =$('input[name="optradio"]:checked').val();
		$.ajax({
		type: "GET",
		url: "newUserSignUp.php",
		data:({"username1":username1,"password1":password1,"firstName1":firstName1,"lastName1":lastName1,"emailAddress1":emailAddress1,"phoneNumber1":phoneNumber1,"optradio":optradio}),
		complete: function(data) {
			alert ('You are successfully signed in!');
		}
	});
	});
});

