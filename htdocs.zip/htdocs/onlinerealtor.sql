-- phpMyAdmin SQL Dump
-- version 4.2.7
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Apr 30, 2016 at 04:34 AM
-- Server version: 5.5.41-log
-- PHP Version: 7.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `onlinerealtor`
--

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

CREATE TABLE IF NOT EXISTS `favorites` (
  `user_id` int(10) NOT NULL,
  `property_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `favorites`
--

INSERT INTO `favorites` (`user_id`, `property_id`) VALUES
(1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `property_mst`
--

CREATE TABLE IF NOT EXISTS `property_mst` (
`property_id` int(10) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `location` varchar(50) NOT NULL,
  `type_id` int(11) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `inMarket` tinyint(1) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='This is the property master table' AUTO_INCREMENT=7 ;

--
-- Dumping data for table `property_mst`
--

INSERT INTO `property_mst` (`property_id`, `title`, `description`, `location`, `type_id`, `price`, `inMarket`) VALUES
(3, 'Vintage Beach House Updated', 'This is Vintage beach house, fully furnished and 3 BR and 2.5 BATH', 'Corpus Christie', 1, 350000.00, 1),
(6, 'New Condo', 'This is a 2 BR condo in an amazing locality and all amenities are included.', 'Dallas', 2, 145000.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `type_mst`
--

CREATE TABLE IF NOT EXISTS `type_mst` (
  `type_id` int(10) NOT NULL,
  `type_name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type_mst`
--

INSERT INTO `type_mst` (`type_id`, `type_name`) VALUES
(1, 'Own House'),
(2, 'Condo'),
(3, 'Beach House'),
(4, 'Apartment'),
(5, 'Town Home'),
(6, 'Villa');

-- --------------------------------------------------------

--
-- Table structure for table `user_mst`
--

CREATE TABLE IF NOT EXISTS `user_mst` (
`user_id` int(10) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email_address` varchar(50) NOT NULL,
  `phone_number` varchar(10) DEFAULT NULL,
  `isAgent` tinyint(1) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='This is the user master table for both buyer and agent' AUTO_INCREMENT=8 ;

--
-- Dumping data for table `user_mst`
--

INSERT INTO `user_mst` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `email_address`, `phone_number`, `isAgent`) VALUES
(1, 'prv130030', 'Pa55word', 'Parth', 'Vyas', 'prv130030@utdallas.edu', '6179829362', 0),
(2, 'catchapu', 'Pa55word', 'Apoorv', 'Kumar', 'catchapu@utdallas.edu', '4694129099', 0),
(3, 'unp130030', 'Pa55word', 'Ujas', 'Patel', 'unp130030@utdallas.edu', '4697329712', 1),
(4, 'mxa147230', 'password', 'Megha', 'Agrawal', 'megha@gmail.com', '23456', 0),
(5, 'justCheck', 'pass', 'Just', 'Check', 'pas', '809797987', 0),
(6, 'nurcan', 'password', 'Nurcan', 'Yuruk', 'nurcan.yuruk@utdallas.edu', '1234567890', 1),
(7, 'user123', 'password', 'Shakti', 'Agrawal', 's.agrawal@gmail.com', '9879099090', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `property_mst`
--
ALTER TABLE `property_mst`
 ADD PRIMARY KEY (`property_id`), ADD KEY `fk_type_id` (`type_id`);

--
-- Indexes for table `type_mst`
--
ALTER TABLE `type_mst`
 ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `user_mst`
--
ALTER TABLE `user_mst`
 ADD PRIMARY KEY (`user_id`), ADD UNIQUE KEY `user_name` (`user_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `property_mst`
--
ALTER TABLE `property_mst`
MODIFY `property_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user_mst`
--
ALTER TABLE `user_mst`
MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `property_mst`
--
ALTER TABLE `property_mst`
ADD CONSTRAINT `fk_type_id` FOREIGN KEY (`type_id`) REFERENCES `type_mst` (`type_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
