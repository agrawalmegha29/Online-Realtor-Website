<?php
$usernameUsr = $_GET['username1'];
$passwordUsr = $_GET['password1'];
$firstName = $_GET['firstName1'];
$lastName = $_GET['lastName1'];
$emailAddress = $_GET['emailAddress1'];
$phoneNumber = $_GET['phoneNumber1'];
$optradio = $_GET['optradio'];
$agent = 1;
$buyer = 0;

// Enter username and password
$username = root;
$password = root;
try{
	// Create database connection using PHP Data Object (PDO)
	$db = new PDO("mysql:host=localhost;dbname=onlinerealtor", $username, $password);
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	//echo "Connected successfully"; 
}catch(PDOException $e){
	//echo "connection failed" .$e-> getMessage();
}
	
$stmt = $db->prepare("INSERT INTO user_mst (`user_name`, `password`, `first_name`, `last_name`, `email_address`, `phone_number`, `isAgent`) VALUES (?,?,?,?,?,?,?)");

$stmt->bindParam(1, $usernameUsr);
$stmt->bindParam(2, $passwordUsr);
$stmt->bindParam(3, $firstName);
$stmt->bindParam(4, $lastName);
$stmt->bindParam(5, $emailAddress);
$stmt->bindParam(6, $phoneNumber);
if(strcmp($optradio, "Yes")==0){
$stmt->bindParam(7, $agent);	
}else{
$stmt->bindParam(7, $buyer);	
}

$stmt->execute();


			
?>