$(document).ready(function(){
	
	$('#srchResult').hide();
	$.ajax({
		type: "GET",
		url: "propertyList.php",
		dataType: "xml",
		async: false,
		success: function(response) {
			var outputResponse = "";
			var counter = 0;
			var loc = document.getElementById("location1");
			$(response).find("propertyList").each(function(){
				counter++;
				var title = $(this).find('title').text();
				var description = $(this).find('description').text();
				var locationProp = $(this).find('location').text();
				loc.innerHTML += "<option value=\"" + locationProp + "\">" + locationProp + "</option>";
				var price = $(this).find('price').text();
				outputResponse+= "<div class=\"col-lg-4 col-md-4 col-sm-6 col-xs-6\"><div class=\"thumbnail\"> <img src=\"images/hd_1.png\" alt=\"Thumbnail Image 1\" class=\"img-responsive\"><div class=\"caption\"><h3>"+title+"</h3><p>"+description+", "+locationProp+", $"+price+"</p><hr><p class=\"text-center\"><a href=\"#buyerModal\" data-toggle=\"modal\" data-target=\"#buyerModal\" class=\"btn btn-success\" role=\"button\" data-toggle=\"modal\" data-target=\"#buyerModal\">Add to Favorites</a></p></div></div></div>"
				if (counter<=3) {
						document.getElementById("propertyData1").innerHTML = outputResponse;
						if (counter==3) {
							outputResponse = "";
						}
				}
				else {
						document.getElementById("propertyData2").innerHTML = outputResponse;
				}
			});
		},
		error:function(){
			alert("error accessing database")
		}
	});
	
	$.ajax({
		type: "GET",
		url: "userList.php",
		dataType: "xml",
		async: false,
		success: function(response) {
			var outputResponseA = "";
			$(response).find("userList").each(function(){
				var first_name = $(this).find('first_name').text();
				var last_name = $(this).find('last_name').text();
				var email_address = $(this).find('email_address').text();
				var phone_number = $(this).find('phone_number').text();
				var isAgent = $(this).find('isAgent').text();
				if (isAgent == 1) {
						outputResponseA+= "<div class=\"media\"><div class=\"media-body\"><h4 class=\"media-heading\">"+first_name+" "+last_name+"</h4><abbr title=\"Phone\">P:</abbr> "+phone_number+" <br> <a href=\"mailto:#\"> "+email_address+"</a> </div></div>";
				}
			});
			document.getElementById("agentDetails").innerHTML = outputResponseA;
		},
		error:function(){
			alert("error accessing database")
		}
	});
	$("#buyerLogin").click(function()
	{
		var pass = $('#passwordB').val();
		var usrN = $('#usernameB').val();
		window.location = "buyerLoginPage.html?password="+pass+"&username="+usrN;
	});
	
$("#agentLogin").click(function()
	{
		var passA = $('#passwordA').val();
		var usrNA = $('#usernameA').val();
		window.location = "agentLoginPage.html?password="+passA+"&username="+usrNA;
	});
});
function searchStart() {
		var location1 =$("#location1").val();
		$.ajax({
		type: "POST",
		url: "searchResults.php",
		data: ({"location1": location1}),
		dataType: "xml",
		async: false,
		success: function(response) {
			var outputResponseF = "<tr><th>Title</th><th>Location</th></tr>";
			$(response).find("propertyList").each(function(){
				var title = $(this).find('title').text();
				var locationProp = $(this).find('location').text();
				outputResponseF+= "<tr><td>" + title + "</td><td>" + locationProp + "</td></tr>";
			});
			$('#srchResult').show();
			document.getElementById("searchList").innerHTML = outputResponseF;
		},
		error:function(){
			alert("error accessing database")
		}
	});
}
	


