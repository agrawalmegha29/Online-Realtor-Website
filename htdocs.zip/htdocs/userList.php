<?php
	// Enter username and password
	$username = root;
	$password = root;

	// Create database connection using PHP Data Object (PDO)
	$db = new PDO("mysql:host=localhost;dbname=onlinerealtor", $username, $password);

	// Identify name of table within database
	$table = 'user_mst';

	// Create the query
	$stmt = $db->query('SELECT * FROM `user_mst`');

	// Close connection to database
	$db = NULL;

	//Creating XML file for passing to JS
	$xml = new SimpleXMLElement('<xml/>');

	while($rows = $stmt->fetch()){
		$userList = $xml->addChild('userList');
		$userList->addChild('first_name', $rows["first_name"]);
		$userList->addChild('last_name', $rows["last_name"]);
		$userList->addChild('email_address', $rows["email_address"]);
		$userList->addChild('phone_number', $rows["phone_number"]);
		$userList->addChild('isAgent', $rows["isAgent"]);
	};

	//Sending XML Data back to JS
	echo($xml->asXML());
	
?>
