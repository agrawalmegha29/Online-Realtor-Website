$(document).ready(function(){
	 var query = window.location.search.substring(1);
	 var squery = query.split("&");
	 var propIdArray = query.split("=");
	 var propId = propIdArray[1];
	 var title;
	 var locationProp;
	 var description;
	 var type_id;
	 var price;
	 var type;
	 
	$.ajax({
		type: "POST",
		url: "editListing.php",
		data: ({"propId": propId}),
		dataType: "xml",
		async: false,
		success: function(response) {
			$(response).find("propertyList").each(function(){
				title = $(this).find('title').text();
				locationProp = $(this).find('location').text();
				description = $(this).find('description').text();
				type_id = $(this).find('type_id').text();
				price = $(this).find('price').text();
			});
			if (type_id == '1') {
				type = "Own House";
			} else if (type_id == '2') {
				type = "Condo";
			} else if (type_id == '3') {
				type = "Beach House";
			} else if (type_id == '4') {
				type = "Apartment";
			} else if (type_id == '5') {
				type = "Town Home";
			} else if (type_id == '6') {
				type = "Villa";
			}
			document.getElementById('titleU').value = title;
			document.getElementById('locationU').value = locationProp;
			document.getElementById('descriptionU').value = description;
			document.getElementById('typeU').value = type;
			document.getElementById('priceU').value = price;
		},
		error:function(){
			alert("error accessing database")
		}
	});
	
	$("button#submit").click(function()
	{
		var title1 =$("#titleU").val();
		var description1 =$("#descriptionU").val();
		var location1 =$("#locationU").val();
		var type1 =$("#typeU").val();
		var price1 =$("#priceU").val();
		$.ajax({
		type: "GET",
		url: "updateListing.php",
		data:({"propId": propId,"title1":title1,"description1":description1,"location1":location1,"type1":type1,"price1":price1}),
		complete: function(data) {
			alert("You have successfully updated the listing");
		}
	});
	});
});

