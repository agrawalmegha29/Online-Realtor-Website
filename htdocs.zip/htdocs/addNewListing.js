$(document).ready(function(){
	$("button#submit").click(function()
	{
		var title1 =$("#title1").val();
		var description1 =$("#description1").val();
		var location1 =$("#location1").val();
		var type1 =$("#type1").val();
		var price1 =$("#price1").val();
		$.ajax({
		type: "GET",
		url: "addNewListing.php",
		data:({"title1":title1,"description1":description1,"location1":location1,"type1":type1,"price1":price1}),
		complete: function(data) {
			alert("You have successfully added the listing");
		}
	});
	});
});

