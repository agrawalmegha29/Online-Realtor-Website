<?php
	
	$userNameBuy=$_GET['userNameBuyer'];
	$passwordVal=$_GET['passwordVal'];

	// Enter username and password
	$username = root;
	$password = root;

	// Create database connection using PHP Data Object (PDO)
	$db = new PDO("mysql:host=localhost;dbname=onlinerealtor", $username, $password);

	// Identify name of table within database
	$table = 'user_mst';

	// Create the query
	$stmt = $db->prepare('SELECT * FROM `user_mst` WHERE `user_name` = ? and `password` = ?;');
	$stmt->bindParam(1, $userNameBuy);
	$stmt->bindParam(2, $passwordVal);
	$stmt->execute();

	// Close connection to database
	$db = NULL;

	//Creating XML file for passing to JS
	$results = $stmt->fetch();
	//echo("This is passed");
	//if (!$results) {
	//	echo("The username and password entered are incorrect, please enter correct credentials.");
	//}elseif {
		$resultsFN = $results["first_name"];
		$resultsLN = $results["last_name"];
		$finalresults = $resultsFN."&".$resultsLN;
		echo ($finalresults);
	//}	
?>
