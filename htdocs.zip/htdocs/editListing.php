<?php
	
	$propId = $_POST['propId'];
	
	// Enter username and password
	$username = root;
	$password = root;

	// Create database connection using PHP Data Object (PDO)
	$db = new PDO("mysql:host=localhost;dbname=onlinerealtor", $username, $password);

	// Identify name of table within database
	$table = 'property_mst';

	// Create the query
	
		$stmt = $db->prepare('SELECT * FROM `property_mst` where property_id = ?');
	
	$stmt->bindParam(1, $propId);
	$stmt->execute();

	// Close connection to database
	$db = NULL;

	//Creating XML file for passing to JS
	$xml = new SimpleXMLElement('<xml/>');

	while($rows = $stmt->fetch()){
		$propertyList = $xml->addChild('propertyList');
		$propertyList->addChild('title', $rows["title"]);
		$propertyList->addChild('description', $rows["description"]);
		$propertyList->addChild('location', $rows["location"]);
		$propertyList->addChild('price', $rows["price"]);
		$propertyList->addChild('type_id', $rows["type_id"]);
		$propertyList->addChild('property_id', $rows["property_id"]);
	};

	//Sending XML Data back to JS
	echo($xml->asXML());
	
?>
