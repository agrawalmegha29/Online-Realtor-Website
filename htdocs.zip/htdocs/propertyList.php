<?php
	// Enter username and password
	$username = root;
	$password = root;

	// Create database connection using PHP Data Object (PDO)
	$db = new PDO("mysql:host=localhost;dbname=onlinerealtor", $username, $password);

	// Identify name of table within database
	$table = 'property_mst';

	// Create the query
	$stmt = $db->query('SELECT * FROM `property_mst`');

	// Close connection to database
	$db = NULL;

	//Creating XML file for passing to JS
	$xml = new SimpleXMLElement('<xml/>');

	while($rows = $stmt->fetch()){
		$propertyList = $xml->addChild('propertyList');
		$propertyList->addChild('property_id', $rows["property_id"]);
		$propertyList->addChild('title', $rows["title"]);
		$propertyList->addChild('description', $rows["description"]);
		$propertyList->addChild('location', $rows["location"]);
		$propertyList->addChild('type', $rows["type_id"]);
		$propertyList->addChild('price', $rows["price"]);
		$propertyList->addChild('inMarket', $rows["inMarket"]);
	};

	//Sending XML Data back to JS
	echo($xml->asXML());
	
?>
