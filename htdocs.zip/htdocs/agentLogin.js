$(document).ready(function(){
	
	/*$.ajax({
		type: "GET",
		url: "userList.php",
		dataType: "xml",
		async: false,
		success: function(response) {
			var outputResponseU = "";
			$(response).find("userList").each(function(){
				var first_name = $(this).find('first_name').text();
				var last_name = $(this).find('last_name').text();
						if (first_name == "Ujas") {
								outputResponseU+= "<li class=\"dropdown\"> <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\" aria-haspopup=\"true\">Welcome, "+first_name+" "+last_name+" <span class=\"caret\"></span></a><ul class=\"dropdown-menu\"><li><a href=\"mainHomePage.html\">Sign Out</a></li></ul></li>";
						}			
			});
			document.getElementById("details").innerHTML = outputResponseU;
		},
		error:function(){
			alert("error accessing database")
		}
	});*/
	
	var query = window.location.search.substring(1);
	var squery = query.split("&");
	var userDetailsArray = query.split("=");
	var userNameVal = userDetailsArray[2];
	var nquery = userDetailsArray[1];
	var passwordArray = nquery.split("&");
	var passwordVal = passwordArray[0];
	$.ajax({
		type: "GET",
		url: "login.php",
		data:({"userNameBuyer":userNameVal,"passwordVal":passwordVal}),
		async: false,
		success: function(response) {
			var names = response.split("&");
			var first_name = names[0];
			var last_name = names[1];
			var outputResponseU= "<li class=\"dropdown\"> <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\" aria-haspopup=\"true\">Welcome, "+first_name+" "+last_name+" <span class=\"caret\"></span></a><ul class=\"dropdown-menu\"><li><a href=\"mainHomePage.html\">Sign Out</a></li></ul></li>";
			document.getElementById("details").innerHTML = outputResponseU;
		},
		error:function(){
			alert("error accessing database")
		}
	});
	
	$.ajax({
		type: "GET",
		url: "propertyList.php",
		dataType: "xml",
		async: false,
		success: function(response) {
			var outputResponse = "";
			var counter = 0;
			$(response).find("propertyList").each(function(){
				counter++;
				var propertyId = $(this).find('property_id').text();
				var title = $(this).find('title').text();
				var description = $(this).find('description').text();
				var locationProp = $(this).find('location').text();
				var price = $(this).find('price').text();
				outputResponse+= "<div class=\"col-lg-4 col-md-4 col-sm-6 col-xs-6\"><div class=\"thumbnail\"> <img src=\"images/hd_1.png\" alt=\"Thumbnail Image 1\" class=\"img-responsive\"><div class=\"caption\"><a href=\"updateListing.html?propId="+propertyId+"\"><h3>"+title+"</h3><p>"+description+", "+locationProp+", $"+price+"</p></a><hr><p class=\"text-center\"><button class=\"btn btn-primary\" id=\""+propertyId+"\" onclick=\"deleteProp(this);\">Delete</button></p></div></div></div>"
				if (counter<=3) {
						document.getElementById("propertyData1").innerHTML = outputResponse;
						if (counter==3) {
							outputResponse = "";
						}
				}
				else {
						document.getElementById("propertyData2").innerHTML = outputResponse;
				}
			});
		},
		error:function(){
			alert("error accessing database")
		}
	});
});

function deleteProp(elem) {
		var propId = $(elem).attr("id");
		$.ajax({
		type: "POST",
		url: "deleteListing.php",
		data: ({"propId": propId}),
		dataType: "xml",
		async: false,
		success: function(response) {
			alert('Your Listing has been deleted');
		},
		error:function(){
			alert("error accessing database")
		}
	});
}

