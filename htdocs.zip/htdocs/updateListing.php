<?php
$propId = $_GET['propId'];
$title1 = $_GET['title1'];
$description1 = $_GET['description1'];
$location1 = $_GET['location1'];
$type1 = $_GET['type1'];
$price1 = $_GET['price1'];
$inMarket1 = 1;
$typeId = 1;
$option1="Own House";
$option2="Condo";
$option3="Beach House";
$option4="Apartment";	
$option5="Town Home";
$option6="Villa";
if(strcmp($type1, "option1")==0){
	$typeId = 1;
}elseif(strcmp($type1, "option2")==0){
	$typeId = 2;
}elseif(strcmp($type1, "option3")==0){
	$typeId = 3;
}elseif(strcmp($type1, "option4")==0){
	$typeId = 4;
}elseif(strcmp($type1, "option5")==0){
	$typeId = 5;
}elseif(strcmp($type1, "option6")==0){
	$typeId = 6;
}
// Enter username and password
$username = root;
$password = root;
try{
	// Create database connection using PHP Data Object (PDO)
	$db = new PDO("mysql:host=localhost;dbname=onlinerealtor", $username, $password);
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	//echo "Connected successfully"; 
}catch(PDOException $e){
	//echo "connection failed" .$e-> getMessage();
}
	
$stmt = $db->prepare('UPDATE `property_mst` SET `property_id`=?,`title`=?,`description`=?,`location`=?,`type_id`=?,`price`=?,`inMarket`=? WHERE `property_id` = ?');

$stmt->bindParam(1, $propId);
$stmt->bindParam(2, $title1);
$stmt->bindParam(3, $description1);
$stmt->bindParam(4, $location1);
$stmt->bindParam(5, $typeId);
$stmt->bindParam(6, $price1);
$stmt->bindParam(7, $inMarket1);
$stmt->bindParam(8, $propId);
$stmt->execute();


			
?>