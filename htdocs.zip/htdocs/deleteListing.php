<?php
	
	$propId = $_POST['propId'];
	
	// Enter username and password
	$username = root;
	$password = root;

	// Create database connection using PHP Data Object (PDO)
	$db = new PDO("mysql:host=localhost;dbname=onlinerealtor", $username, $password);

	// Identify name of table within database
	$table = 'property_mst';

	// Create the query
		$stmt = $db->prepare('DELETE FROM `property_mst` WHERE property_id = ?');
	$stmt->bindParam(1, $propId);
	$stmt->execute();

	// Close connection to database
	$db = NULL;
	
?>
